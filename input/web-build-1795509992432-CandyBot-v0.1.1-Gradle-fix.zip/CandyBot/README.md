# CandyBot 0.1
Experimental native Android source, not an APK. Requires Android Studio, JDK 17, Android SDK 36 and Gradle 8.11.1. Open this directory in Android Studio, sync and select Build APK. Install the resulting debug APK. No network permission or root required. Android may require Allow restricted settings in App info before enabling accessibility for sideloaded apps.

Open CandyBot and enable its accessibility service. Open Candy Crush Saga. Use Setup to enter pixel coordinates of the centers of the top-left and bottom-right cells, and row/column counts. A screenshot viewed in an image editor can help determine coordinates. Keep portrait orientation and ensure the floating controls do not cover the board. Press Start; Stop cancels future moves. The bot stops on leaving Saga, low recognition confidence, no recognized move or repeated unchanged moves. Disable accessibility when finished.

Limitations: uncompiled and untested on device. HSV color recognition is heuristic; blockers, special candies, irregular boards, objectives, level transitions and purchases are not supported. Misclassification can produce incorrect swipes. Supervise use; do not run unattended. Game terms may prohibit automation. Screen pixels are processed locally in memory. No original game files are modified.

Build compatibility: AGP 8.7.3, Gradle 8.9, JDK 17, Android SDK 35. Runs on Android 16 subject to device testing.
