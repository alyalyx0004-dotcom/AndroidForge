package com.candybot;
public class Solver {
 static int run(int[] a,int r,int c,int R,int C,int dr,int dc){int k=a[r*C+c]%10;if(k<0||k==6)return 0;int n=1;for(int s:new int[]{-1,1}){int y=r+s*dr,x=c+s*dc;while(y>=0&&y<R&&x>=0&&x<C&&a[y*C+x]%10==k){n++;y+=s*dr;x+=s*dc;}}return n;}
 static int score(int[] a,int i,int R,int C){int h=run(a,i/C,i%C,R,C,0,1),v=run(a,i/C,i%C,R,C,1,0);return (h>=3?h*h:0)+(v>=3?v*v:0)+(h>=3&&v>=3?20:0);}
 public static int[] best(int[] a,int R,int C){int best=0;int[] move=null;for(int i=0;i<a.length;i++){if(a[i]<0)continue;for(int j:new int[]{i%C<C-1?i+1:-1,i/C<R-1?i+C:-1}){if(j<0||a[j]<0)continue;if(a[i]==6||a[j]==6)return new int[]{i,j};if(a[i]>=10&&a[j]>=10)return new int[]{i,j};if(a[i]%10==a[j]%10)continue;int t=a[i];a[i]=a[j];a[j]=t;int s=score(a,i,R,C)+score(a,j,R,C);if(s>0&&(a[i]>=10||a[j]>=10))s+=12;a[j]=a[i];a[i]=t;if(s>best){best=s;move=new int[]{i,j};}}}return move;}
}
