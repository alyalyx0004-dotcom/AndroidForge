package com.candybot;
import android.graphics.*;
class Detector {
 static class Board {int rows,cols; float x,y,dx,dy; int[] cells; float quality;}
 // Detect the repeated blue/purple tile background using scan-line projections.
 static boolean tile(int p){int r=Color.red(p),g=Color.green(p),b=Color.blue(p);return b>r+12&&b>g+8&&b>65&&r>35;}
 static Board detect(Bitmap b){int w=b.getWidth(),h=b.getHeight(),step=Math.max(2,w/240); int[] xs=new int[w],ys=new int[h];
 for(int y=h*24/100;y<h*79/100;y+=step)for(int x=0;x<w;x+=step)if(tile(b.getPixel(x,y))){xs[x]++;ys[y]++;}
 int[] xx=extent(xs,step),yy=extent(ys,step);if(xx==null||yy==null)return null;
 float bw=xx[1]-xx[0]+step,bh=yy[1]-yy[0]+step; Board best=null;
 for(int r=3;r<=12;r++)for(int c=3;c<=12;c++){float dx=bw/c,dy=bh/r;if(dx<w*.065||dx>w*.19||Math.abs(dx/dy-1)>.13)continue;Board q=new Board();q.rows=r;q.cols=c;q.dx=dx;q.dy=dy;q.x=xx[0]+dx/2;q.y=yy[0]+dy/2;q.cells=new int[r*c];int known=0;float conf=0;
 for(int i=0;i<q.cells.length;i++){float[] v=sample(b,q.x+i%c*dx,q.y+i/c*dy,Math.min(dx,dy));q.cells[i]=(int)v[0];if(q.cells[i]>=0)known++;conf+=v[1];}
 q.quality=conf/q.cells.length+known/(float)q.cells.length*.22f-Math.abs(dx/dy-1)*.7f-Math.abs(dx/w-.107f)*2f;if(known>=4&&(best==null||q.quality>best.quality))best=q;
 }return best!=null&&best.quality>.18?best:null;}
 static int[] extent(int[] a,int step){int max=0;for(int v:a)max=Math.max(max,v);if(max<5)return null;int lo=-1,hi=-1;for(int i=0;i<a.length;i+=step)if(a[i]>=max*.24){if(lo<0)lo=i;hi=i;}return hi>lo?new int[]{lo,hi}:null;}
 static float[] sample(Bitmap b,float x,float y,float d){int[] v=new int[6];int dark=0,white=0,n=0;float[] hsv=new float[3];for(int j=-4;j<=4;j++)for(int i=-4;i<=4;i++){int px=Math.round(x+i*d*.065f),py=Math.round(y+j*d*.065f);if(px<0||py<0||px>=b.getWidth()||py>=b.getHeight())continue;n++;Color.colorToHSV(b.getPixel(px,py),hsv);if(hsv[2]<.30){dark++;continue;}if(hsv[1]<.20&&hsv[2]>.8)white++;if(hsv[1]<.65||hsv[2]<.43)continue;float z=hsv[0];int k=z<12||z>=350?0:z<49?1:z<76?2:z<155?3:z>190&&z<245?4:z>265&&z<310?5:-1;if(k>=0)v[k]++;}int k=0,distinct=0;for(int i=0;i<6;i++){if(v[i]>v[k])k=i;if(v[i]>=3)distinct++;}if(dark>12&&distinct>=3)return new float[]{6,.8f};if(dark>15||n==0||v[k]<n*.36)return new float[]{-1,0};return new float[]{k+(white>13?10:0),v[k]/(float)n};}
}
