package com.candybot;
import android.app.*;import android.os.*;import android.content.*;import android.provider.Settings;import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(32,48,32,32);setContentView(l);TextView t=new TextView(this);t.setText("CandyBot 0.2 — experimental\nEnable CandyBot in Accessibility settings, open Saga, then use the floating controls. Press the floating Start button. Automatic board detection and special candy recognition are experimental. Stop if moves are incorrect.");l.addView(t);Button a=new Button(this);a.setText("Accessibility settings");l.addView(a);a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); }
}
